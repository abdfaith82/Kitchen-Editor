package com.prokitchen.designer

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.widget.SeekBar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.prokitchen.designer.camera.CameraScanView
import com.prokitchen.designer.data.ProjectDatabase
import com.prokitchen.designer.data.ProjectEntity
import com.prokitchen.designer.export.BillOfMaterials
import com.prokitchen.designer.export.DesignPdfExporter
import com.prokitchen.designer.export.ObjLayoutExporter
import com.prokitchen.designer.materials.PbrMaterialCatalog
import com.prokitchen.designer.materials.MaterialCategory
import com.prokitchen.designer.render.RenderConfiguration
import com.prokitchen.designer.importer.UniversalObjectImporter
import com.prokitchen.designer.importer.ImportResult
import com.prokitchen.designer.modeling.AluminumProfiles
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.prokitchen.designer.model.*
import com.prokitchen.designer.ui.PlanCanvasView
import org.json.JSONObject
import java.io.OutputStreamWriter
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private var doc = PlanDocument()
    private lateinit var canvasView: PlanCanvasView
    private lateinit var status: TextView
    private lateinit var workspace: FrameLayout
    private lateinit var titleView: TextView
    private var autosaveJob: Job? = null
    private var renderConfig = RenderConfiguration()
    private var cameraPermissionRequest = 7201
    private val saveJson = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) contentResolver.openOutputStream(uri)?.use { it.write(doc.toJson().toByteArray()) ; toast("تم تصدير ملف المخطط JSON") }
    }
    private val savePng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) {
            val bitmap = Bitmap.createBitmap(max(900, canvasView.width), max(900, canvasView.height), Bitmap.Config.ARGB_8888)
            canvasView.draw(Canvas(bitmap))
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("تم تصدير صورة المخطط")
        }
    }
    private val importJson = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val json = contentResolver.openInputStream(uri)!!.bufferedReader().readText()
            doc = PlanDocument.fromJson(json); refreshCanvas(); toast("تم استيراد المخطط")
        }.onFailure { toast("تعذر قراءة الملف: ${it.message}") }
    }
    private val importImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) lifecycleScope.launch {
            val analysis = runCatching {
                withContext(Dispatchers.IO) {
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 1600) sample *= 2
                    val options = android.graphics.BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    val bitmap = contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
                        ?: error("تعذر فك الصورة")
                    try { com.prokitchen.designer.camera.RoomImageAnalyzer.analyze(bitmap) } finally { bitmap.recycle() }
                }
            }
            analysis.onSuccess { result ->
                val message = "تحليل حواف محلي (ليس نموذج ذكاء اصطناعي)\n" +
                    "حجم التحليل: ${result.width} × ${result.height}\n" +
                    "كثافة الحواف: ${String.format(java.util.Locale.getDefault(), "%.1f", result.edgeDensity * 100)}%\n" +
                    "مؤشر الحواف الأفقية: ${String.format(java.util.Locale.getDefault(), "%.0f", result.horizontalEdgeScore * 100)}%\n" +
                    "مؤشر الحواف العمودية: ${String.format(java.util.Locale.getDefault(), "%.0f", result.verticalEdgeScore * 100)}%\n" +
                    "الثقة: ${result.confidence}\n\nنسبة الصورة ليست قياسًا موثوقًا لأبعاد الغرفة بسبب المنظور."
                AlertDialog.Builder(this@MainActivity).setTitle("تحليل صورة الغرفة").setMessage(message)
                    .setNegativeButton("إغلاق", null)
                    .setPositiveButton("قالب تقريبي جديد") { _, _ ->
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("استبدال المخطط الحالي؟")
                            .setMessage("سيتم إنشاء قالب غرفة تقريبي باستخدام نسبة الصورة، مع الاحتفاظ بنسخة المشروع السابقة في الحفظ المحلي فقط بعد الحفظ السابق. أدخل القياسات الحقيقية قبل الاعتماد على التصميم.")
                            .setNegativeButton("إلغاء", null)
                            .setPositiveButton("استبدال") { _, _ ->
                                val width = 420f
                                val depth = (width / result.suggestedAspectRatio).coerceIn(300f, 600f)
                                doc = PlanDocument(name = "Room Photo Template", widthCm = width, depthCm = depth).apply { addDefaultRoom() }
                                refreshCanvas()
                                scheduleAutosave()
                                updateStatus("تم إنشاء قالب تقريبي؛ عدّل الأبعاد بناءً على قياس الغرفة الحقيقي")
                            }.show()
                    }.show()
            }.onFailure { toast("تعذر تحليل الصورة: ${it.message}") }
        }
    }
    private val importObject = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) lifecycleScope.launch {
            val result = UniversalObjectImporter(this@MainActivity).importFile(uri) { progress, message -> runOnUiThread { updateStatus("${(progress*100).toInt()}% • $message") } }
            when (result) {
                is ImportResult.Success -> {
                    if (result.asset.format == com.prokitchen.designer.importer.ImportFormat.GLB) {
                        startActivity(Intent(this@MainActivity, com.prokitchen.designer.viewer.GlbViewerActivity::class.java)
                            .putExtra(com.prokitchen.designer.viewer.GlbViewerActivity.EXTRA_MODEL_PATH, result.asset.localPath)
                            .putExtra(com.prokitchen.designer.viewer.GlbViewerActivity.EXTRA_MODEL_NAME, result.asset.displayName))
                    } else {
                        toast("تم فحص ${result.asset.displayName}. عرض OBJ داخل Filament يحتاج تحويلًا إلى GLB أولًا.")
                    }
                }
                is ImportResult.RequiresConversion -> toast(result.reason)
                is ImportResult.UnsupportedFormat -> toast("صيغة غير مدعومة: ${result.extension}")
                is ImportResult.Error -> toast(result.message)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        doc.addDefaultRoom()
        buildUi()
        lifecycleScope.launch {
            runCatching { withContext(Dispatchers.IO) { ProjectDatabase.get(this@MainActivity).projectDao().get() } }
                .getOrNull()?.let { saved -> runCatching { doc = PlanDocument.fromJson(saved.json); refreshCanvas(); updateStatus("تم استعادة آخر حفظ محلي") } }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,245,240)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 18, 20, 14); setBackgroundColor(Color.rgb(22,56,59))
        }
        header.addView(TextView(this).apply { text = "PROKITCHEN"; textSize = 12f; setTextColor(Color.rgb(214,168,106)); letterSpacing = .18f })
        titleView = TextView(this).apply { text = "Home Designer Ultimate"; textSize = 23f; setTextColor(Color.WHITE); setPadding(0,5,0,3); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        header.addView(titleView)
        header.addView(TextView(this).apply { text = "ارسم • صمّم • تصوّر"; textSize = 13f; setTextColor(Color.rgb(213,225,220)) })
        root.addView(header)
        val toolsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(10,10,10,10) }
        fun toolButton(label: String, action: () -> Unit) {
            tools.addView(Button(this).apply { text = label; textSize = 12f; isAllCaps = false; setOnClickListener { action() } },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 48).apply { setMargins(3,0,3,0) })
        }
        toolButton("جدار") { canvasView.tool = PlanCanvasView.Tool.WALL; updateStatus("اسحب لرسم جدار") }
        toolButton("نافذة") { canvasView.tool = PlanCanvasView.Tool.WINDOW; updateStatus("اسحب لتحديد عرض النافذة") }
        toolButton("باب") { canvasView.tool = PlanCanvasView.Tool.DOOR; updateStatus("اسحب لتحديد فتحة الباب") }
        toolButton("أثاث") { canvasView.tool = PlanCanvasView.Tool.FURNITURE; updateStatus("اسحب لرسم قطعة أثاث") }
        toolButton("ممحاة") { canvasView.tool = PlanCanvasView.Tool.ERASE; updateStatus("المس عنصراً لحذفه") }
        toolButton("تحديد/تحريك") { canvasView.tool = PlanCanvasView.Tool.SELECT; updateStatus("المس قطعة أثاث ثم اسحبها؛ يظهر ظل شفاف أثناء التحريك") }
        toolButton("دوران 45°") { canvasView.rotateSelected45() }
        toolButton("عكس X") { canvasView.flipSelected(true) }
        toolButton("عكس Y") { canvasView.flipSelected(false) }
        toolButton("المسافات") { canvasView.showDistances = !canvasView.showDistances; canvasView.invalidate(); updateStatus(if (canvasView.showDistances) "عرض المسافات مفعّل" else "عرض المسافات متوقف") }
        toolButton("خامات PBR") { showMaterials() }
        toolButton("رندر Live/Final") { showRenderConfiguration() }
        toolButton("كاميرا الغرفة") { openCameraScan() }
        toolButton("قائمة المواد BOM") { showBom() }
        toolButton("استيراد GLB/OBJ") { importObject.launch(arrayOf("model/gltf-binary", "model/gltf+json", "text/plain", "application/octet-stream", "*/*")) }
        toolButton("قص ألمنيوم") { showAluminumCutList() }
        toolsScroll.addView(tools); root.addView(toolsScroll)
        workspace = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        canvasView = PlanCanvasView(this, doc).apply { onChanged = { updateStatus("تم تحديث المخطط • ${doc.elements.size} عنصر"); scheduleAutosave() } }
        workspace.addView(canvasView, FrameLayout.LayoutParams(-1,-1))
        root.addView(workspace, LinearLayout.LayoutParams(-1,0,1f).apply { setMargins(10,0,10,0) })
        status = TextView(this).apply { textSize = 12f; setTextColor(Color.rgb(57,75,72)); setPadding(16,8,16,8); text = "جاهز • اسحب داخل مساحة الرسم" }
        root.addView(status)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(8,0,8,10) }
        fun actionButton(label: String, action: () -> Unit) {
            actions.addView(Button(this).apply { text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() } },
                LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2,0,2,0) })
        }
        actionButton("2D مخطط") { show2D() }
        actionButton("3D معاينة") { show3D() }
        actionButton("رندر") { showRenderPreview() }
        actionButton("جولة") { showWalkthrough() }
        root.addView(actions)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,0,8,10) }
        fun bottomButton(label: String, action: () -> Unit) {
            bottom.addView(Button(this).apply { text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() } },
                LinearLayout.LayoutParams(0,48,1f).apply { setMargins(2,0,2,0) })
        }
        bottomButton("تصدير PNG") { savePng.launch("prokitchen-plan.png") }
        bottomButton("تصدير JSON") { saveJson.launch("prokitchen-plan.json") }
        bottomButton("استيراد مخطط") { importJson.launch(arrayOf("application/json", "text/*")) }
        bottomButton("تحليل صورة") { importImage.launch(arrayOf("image/*")) }
        bottomButton("PDF التصميم") { exportPdf() }
        bottomButton("OBJ ثلاثي الأبعاد") { exportObj() }
        bottomButton("GLTF") { exportGltf() }
        root.addView(bottom)
        setContentView(root)
    }

    private fun refreshCanvas() {
        workspace.removeAllViews()
        canvasView = PlanCanvasView(this, doc).apply { onChanged = { updateStatus("تم تحديث المخطط • ${doc.elements.size} عنصر"); scheduleAutosave() } }
        workspace.addView(canvasView, FrameLayout.LayoutParams(-1,-1))
    }
    private fun scheduleAutosave() {
        autosaveJob?.cancel()
        status.text = "● تغييرات غير محفوظة محليًا"
        autosaveJob = lifecycleScope.launch {
            delay(900)
            val result = runCatching { withContext(Dispatchers.IO) { ProjectDatabase.get(this@MainActivity).projectDao().save(ProjectEntity(name=doc.name, json=doc.toJson())) } }
            status.text = if (result.isSuccess) "● تم الحفظ محليًا في Room" else "● تعذر الحفظ المحلي: ${result.exceptionOrNull()?.message ?: "خطأ"}"
        }
    }
    private fun updateStatus(s: String) { status.text = s }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun showRenderConfiguration() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Live — سريع", "Final — جودة أعلى")); setSelection(if (renderConfig.mode == RenderConfiguration.Mode.LIVE) 0 else 1) }
        panel.addView(TextView(this).apply { text = "وضع الرندر" }); panel.addView(mode)
        val exposureLabel = TextView(this).apply { text = "Exposure: ${"%.1f".format(renderConfig.exposure)} EV" }
        panel.addView(exposureLabel)
        val exposure = SeekBar(this).apply { max = 40; progress = ((renderConfig.exposure + 2f) * 10).toInt().coerceIn(0,40) }
        exposure.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { renderConfig = renderConfig.copy(exposure=progress/10f-2f); exposureLabel.text = "Exposure: ${"%.1f".format(renderConfig.exposure)} EV" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }); panel.addView(exposure)
        val resolution = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, RenderConfiguration.Resolution.entries.map { it.label }); setSelection(RenderConfiguration.Resolution.entries.indexOf(renderConfig.resolution)) }
        panel.addView(TextView(this).apply { text = "دقة التصدير (حتى 4K)" }); panel.addView(resolution)
        AlertDialog.Builder(this).setTitle("إعدادات الرندر").setView(panel).setNegativeButton("إلغاء", null).setPositiveButton("تطبيق") { _, _ ->
            renderConfig = renderConfig.copy(mode=if(mode.selectedItemPosition==0) RenderConfiguration.Mode.LIVE else RenderConfiguration.Mode.FINAL, resolution=RenderConfiguration.Resolution.entries[resolution.selectedItemPosition])
            updateStatus("${renderConfig.mode} • ${renderConfig.resolution.label} • Exposure ${renderConfig.exposure} EV")
            if (renderConfig.mode == RenderConfiguration.Mode.FINAL) showRenderPreview() else show3D()
        }.show()
    }

    private fun showBom() {
        val furniture = doc.elements.filter { it.type == ElementType.FURNITURE }
        if (furniture.isEmpty()) {
            AlertDialog.Builder(this).setTitle("قائمة المواد BOM").setMessage("أضف وحدات أثاث إلى المخطط أولاً.").setPositiveButton("حسنًا", null).show()
            return
        }
        val scroll = ScrollView(this)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 8) }
        val editors = mutableListOf<Triple<Long, EditText, EditText>>()
        panel.addView(TextView(this).apply { text = "أدخل تكلفة الوحدة والكمية. الأبعاد محسوبة من هندسة المخطط بالسنتيمتر."; textSize = 13f; setPadding(0,0,0,10) })
        furniture.forEach { element ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 8, 0, 8) }
            row.addView(TextView(this).apply {
                text = "${element.label.ifBlank { "وحدة مطبخ" }} • ${kotlin.math.abs(element.x2-element.x1).toInt()} × ${kotlin.math.abs(element.y2-element.y1).toInt()} سم"
                textSize = 14f
            })
            val inputs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val quantity = EditText(this).apply {
                hint = "الكمية"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(element.quantity.toString()); setSingleLine(true)
            }
            val cost = EditText(this).apply {
                hint = "سعر الوحدة"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(if (element.unitCost == 0.0) "" else element.unitCost.toString()); setSingleLine(true)
            }
            inputs.addView(quantity, LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(0,0,6,0) })
            inputs.addView(cost, LinearLayout.LayoutParams(0, 52, 1f))
            row.addView(inputs)
            editors += Triple(element.id, quantity, cost)
            panel.addView(row)
            panel.addView(View(this).apply { setBackgroundColor(Color.LTGRAY) }, LinearLayout.LayoutParams(-1, 1))
        }
        val totalLabel = TextView(this).apply { text = "تُحسب التكلفة الإجمالية بعد الحفظ."; setPadding(0, 10, 0, 0) }
        panel.addView(totalLabel)
        scroll.addView(panel)

        fun saveEdits() {
            editors.forEach { (id, quantityInput, costInput) ->
                val index = doc.elements.indexOfFirst { it.id == id }
                if (index >= 0) {
                    val old = doc.elements[index]
                    doc.elements[index] = old.copy(
                        quantity = quantityInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1,
                        unitCost = costInput.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                    )
                }
            }
            val total = BillOfMaterials.from(doc).sumOf { it.total }
            totalLabel.text = "الإجمالي التقديري: ${String.format(java.util.Locale.getDefault(), "%.2f", total)}"
            scheduleAutosave()
            canvasView.invalidate()
        }

        val dialog = AlertDialog.Builder(this).setTitle("معاينة قائمة المواد BOM").setView(scroll)
            .setNegativeButton("إغلاق", null)
            .setPositiveButton("حفظ الأسعار", null)
            .setNeutralButton("PDF", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { saveEdits(); toast("تم حفظ الأسعار والكميات ضمن المشروع") }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { saveEdits(); exportPdf(); dialog.dismiss() }
        }
        dialog.show()
    }

    private fun showMaterials() {
        val categories = listOf("الكل", "خشب", "حجر", "معدن", "خرسانة")
        AlertDialog.Builder(this).setTitle("استوديو الخامات PBR").setItems(categories.toTypedArray()) { _, which ->
            val category = when(which) { 1 -> MaterialCategory.WOOD; 2 -> MaterialCategory.STONE; 3 -> MaterialCategory.METAL; 4 -> MaterialCategory.CONCRETE; else -> null }
            val items = PbrMaterialCatalog.filter(category)
            AlertDialog.Builder(this).setTitle("اختر خامة").setItems(items.map { "${it.name} • ${it.baseColorHex}" }.toTypedArray()) { _, index ->
                val chosen = items[index]
                var changed = 0
                doc.elements.indices.forEach { elementIndex ->
                    val element = doc.elements[elementIndex]
                    if (element.type == ElementType.FURNITURE) {
                        doc.elements[elementIndex] = element.copy(material = chosen.name)
                        changed++
                    }
                }
                scheduleAutosave()
                toast("تم تعيين ${chosen.name} كبيانات خامة لـ $changed وحدة. تطبيق ملفات PBR المصورة على أسطح المشهد ما زال يحتاج ملفات texture فعلية.")
            }.show()
        }.show()
    }

    private fun exportPdf() {
        val bitmap = Bitmap.createBitmap(max(900, canvasView.width), max(700, canvasView.height), Bitmap.Config.ARGB_8888)
        canvasView.draw(Canvas(bitmap))
        lifecycleScope.launch {
            val file = File(cacheDir, "prokitchen-summary.pdf")
            runCatching { withContext(Dispatchers.IO) { DesignPdfExporter.write(this@MainActivity, doc, bitmap, file) } }
                .onSuccess { shareFile(it, "application/pdf") }
                .onFailure { toast("فشل إنشاء PDF: ${it.message}") }
        }
    }

    private fun exportObj() {
        lifecycleScope.launch {
            val file = File(cacheDir, "prokitchen-layout.obj")
            runCatching { withContext(Dispatchers.IO) { ObjLayoutExporter.write(doc, file) }; file }
                .onSuccess { shareFile(it, "text/plain") }
                .onFailure { toast("فشل تصدير OBJ: ${it.message}") }
        }
    }

    private fun exportGltf() {
        lifecycleScope.launch {
            val file = File(cacheDir, "prokitchen-layout.gltf")
            runCatching { withContext(Dispatchers.IO) { com.prokitchen.designer.export.GltfLayoutExporter.write(doc, file) }; file }
                .onSuccess { shareFile(it, "model/gltf+json") }
                .onFailure { toast("فشل تصدير GLTF: ${it.message}") }
        }
    }

    private fun shareFile(file: File, mime: String) {
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type=mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "مشاركة ملف التصميم"))
    }

    private fun showAluminumCutList() {
        val cuts = doc.elements.filter { it.type == ElementType.FURNITURE }.flatMap { e ->
            val w = kotlin.math.abs(e.x2-e.x1).toInt()*10
            val d = kotlin.math.abs(e.y2-e.y1).toInt()*10
            listOf(AluminumProfiles.Cut("${e.label}-W", w, 2), AluminumProfiles.Cut("${e.label}-D", d, 2))
        }
        runCatching { AluminumProfiles.optimize(cuts) }.onSuccess { bars ->
            val details = bars.joinToString("\n") { "قضيب ${it.index}: ${it.cutsMm.joinToString(" + ")} مم | هدر ${it.wasteMm} مم" }
            AlertDialog.Builder(this).setTitle("قائمة قص قطاعات الألمنيوم").setMessage("إجمالي القضبان: ${bars.size}\n$details")
                .setNegativeButton("إغلاق", null).setPositiveButton("تصدير CSV") { _, _ ->
                    lifecycleScope.launch {
                        val file = File(cacheDir, "aluminum-cut-list.csv")
                        runCatching { withContext(Dispatchers.IO) { AluminumProfiles.exportCsv(bars, file) }; file }
                            .onSuccess { shareFile(it, "text/csv") }.onFailure { toast("تعذر تصدير CSV: ${it.message}") }
                    }
                }.show()
        }.onFailure { toast("تعذر حساب قائمة القص: ${it.message}") }
    }

    private fun openCameraScan() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), cameraPermissionRequest); return
        }
        val cameraView = CameraScanView(this, this)
        val dialog = AlertDialog.Builder(this).setTitle("تصوير الغرفة").setView(cameraView).setNegativeButton("إغلاق", null).setPositiveButton("التقاط صورة") { _, _ ->
            val target = File(filesDir, "room_scan_${System.currentTimeMillis()}.jpg")
            cameraView.captureTo(target)
            toast("سيتم حفظ صورة الغرفة كمرجع. تحويلها تلقائيًا إلى مخطط يحتاج وحدة رؤية حاسوبية.")
        }.create()
        cameraView.layoutParams = android.view.ViewGroup.LayoutParams(-1, 900)
        cameraView.onError = { toast(it) }
        cameraView.onImageSaved = { file -> toast("حُفظت صورة الغرفة: ${file.name}") }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94).toInt(), (resources.displayMetrics.heightPixels*0.8).toInt())
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == cameraPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) openCameraScan()
        else if (requestCode == cameraPermissionRequest) toast("يلزم السماح بالكاميرا لتصوير الغرفة")
    }

    private fun show2D() { refreshCanvas(); updateStatus("محرر المخطط ثنائي الأبعاد") }

    private fun show3D() {
        val view = SimpleRoomView(this, doc, false)
        workspace.removeAllViews(); workspace.addView(view, FrameLayout.LayoutParams(-1,-1))
        updateStatus("معاينة كتلية ثلاثية الأبعاد مبسطة — ليست محرك رندر نهائياً")
    }

    private fun showRenderPreview() {
        val view = SimpleRoomView(this, doc, true)
        workspace.removeAllViews(); workspace.addView(view, FrameLayout.LayoutParams(-1,-1))
        updateStatus("معاينة إضاءة وخامات توضيحية — الرندر الفوتوغرافي يحتاج محركاً متخصصاً")
    }

    private fun showWalkthrough() {
        val view = SimpleRoomView(this, doc, true)
        workspace.removeAllViews(); workspace.addView(view, FrameLayout.LayoutParams(-1,-1))
        toast("نموذج الجولة الحالي معاينة ثابتة. الحركة داخل الغرفة تحتاج محرك 3D وتفاعل كاميرا.")
    }
}

private class SimpleRoomView(context: android.content.Context, private val doc: PlanDocument, private val rendered: Boolean) : View(context) {
    private val p = android.graphics.Paint(3)
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(if (rendered) Color.rgb(229,224,211) else Color.rgb(247,246,241))
        val w = width.toFloat(); val h = height.toFloat()
        val topX = w*.5f; val topY = h*.18f
        val leftX = w*.12f; val rightX = w*.88f; val bottomY = h*.78f
        val backX1 = w*.30f; val backX2 = w*.70f; val backY = h*.35f
        p.color = if(rendered) Color.rgb(221,211,190) else Color.rgb(230,230,222)
        c.drawPath(Path().apply { moveTo(leftX,topY); lineTo(rightX,topY); lineTo(rightX,bottomY); lineTo(leftX,bottomY); close() }, p)
        p.color = if(rendered) Color.rgb(191,176,150) else Color.rgb(211,214,207)
        c.drawPath(Path().apply { moveTo(leftX,topY); lineTo(backX1,backY); lineTo(backX1,h*.65f); lineTo(leftX,bottomY); close() }, p)
        p.color = if(rendered) Color.rgb(174,158,133) else Color.rgb(195,200,193)
        c.drawPath(Path().apply { moveTo(rightX,topY); lineTo(backX2,backY); lineTo(backX2,h*.65f); lineTo(rightX,bottomY); close() }, p)
        p.color = if(rendered) Color.rgb(185,167,139) else Color.rgb(222,222,213)
        c.drawPath(Path().apply { moveTo(leftX,bottomY); lineTo(rightX,bottomY); lineTo(backX2,h*.65f); lineTo(backX1,h*.65f); close() }, p)
        p.color = Color.rgb(45,68,66); p.textSize = 18f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(if(rendered) "MATERIAL & LIGHT PREVIEW" else "3D ROOM BLOCKOUT", 22f, 32f, p)
        val n = doc.elements.count { it.type == ElementType.FURNITURE }
        p.textSize = 12f; p.typeface = android.graphics.Typeface.DEFAULT
        c.drawText("${doc.widthCm.toInt()} × ${doc.depthCm.toInt()} cm  •  $n furniture items", 22f, 52f, p)
        val counter = RectF(w*.23f,h*.43f,w*.52f,h*.51f)
        p.color = if(rendered) Color.rgb(131,105,76) else Color.rgb(197,177,145)
        c.drawRoundRect(counter, 6f,6f,p)
        p.color = Color.rgb(242,239,229)
        c.drawRect(w*.24f,h*.52f,w*.51f,h*.62f,p)
        p.color = if(rendered) Color.rgb(88,107,102) else Color.rgb(164,181,171)
        c.drawRoundRect(RectF(w*.57f,h*.49f,w*.76f,h*.59f), 7f,7f,p)
        p.color = Color.rgb(255,255,255); p.alpha = if(rendered) 65 else 120
        c.drawRect(w*.33f,h*.22f,w*.46f,h*.32f,p); p.alpha = 255
    }
}
