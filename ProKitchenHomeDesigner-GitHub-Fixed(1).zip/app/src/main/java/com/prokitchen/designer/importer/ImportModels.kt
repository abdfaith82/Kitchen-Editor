package com.prokitchen.designer.importer

/** Import capability is explicit: advertised extension != implemented decoder. */
enum class ImportFormat(val extensions: Set<String>, val capability: Capability) {
    GLB(setOf("glb"), Capability.NATIVE_ASSET),
    GLTF(setOf("gltf"), Capability.NATIVE_ASSET_WITH_RESOURCES),
    OBJ(setOf("obj"), Capability.GEOMETRY_INSPECTION),
    ZIP(setOf("zip"), Capability.SAFE_ARCHIVE),
    FBX(setOf("fbx"), Capability.CONVERTER_REQUIRED),
    THREE_DS(setOf("3ds"), Capability.CONVERTER_REQUIRED),
    DAE(setOf("dae"), Capability.CONVERTER_REQUIRED),
    PLY(setOf("ply"), Capability.CONVERTER_REQUIRED),
    STL(setOf("stl"), Capability.CONVERTER_REQUIRED),
    USDZ(setOf("usdz"), Capability.CONVERTER_REQUIRED),
    USD(setOf("usd"), Capability.CONVERTER_REQUIRED),
    ABC(setOf("abc"), Capability.CONVERTER_REQUIRED),
    BLEND(setOf("blend"), Capability.CONVERTER_REQUIRED),
    SKP(setOf("skp"), Capability.SPECIALIZED_CONVERTER_REQUIRED),
    RHINO(setOf("3dm"), Capability.SPECIALIZED_CONVERTER_REQUIRED),
    IFC(setOf("ifc"), Capability.SPECIALIZED_CONVERTER_REQUIRED),
    REVIT(setOf("rvt"), Capability.SPECIALIZED_CONVERTER_REQUIRED),
    DWG(setOf("dwg"), Capability.SPECIALIZED_CONVERTER_REQUIRED),
    DXF(setOf("dxf"), Capability.CONVERTER_REQUIRED),
    PDF(setOf("pdf"), Capability.PLAN_PARSER_REQUIRED),
    SVG(setOf("svg"), Capability.PLAN_PARSER_REQUIRED),
    DWF(setOf("dwf"), Capability.SPECIALIZED_CONVERTER_REQUIRED),
    KTX(setOf("ktx"), Capability.TEXTURE_PIPELINE_REQUIRED),
    KTX2(setOf("ktx2"), Capability.TEXTURE_PIPELINE_REQUIRED),
    HDR(setOf("hdr"), Capability.ENVIRONMENT_PIPELINE_REQUIRED),
    EXR(setOf("exr"), Capability.ENVIRONMENT_PIPELINE_REQUIRED),
    PNG(setOf("png"), Capability.IMAGE_ASSET),
    JPG(setOf("jpg", "jpeg"), Capability.IMAGE_ASSET),
    SEVEN_Z(setOf("7z"), Capability.ARCHIVE_DECODER_REQUIRED),
    RAR(setOf("rar"), Capability.ARCHIVE_DECODER_REQUIRED);

    companion object {
        private val byExtension = entries.flatMap { format -> format.extensions.map { it to format } }.toMap()
        fun fromExtension(extension: String): ImportFormat? = byExtension[extension.lowercase().removePrefix(".")]
    }
}

enum class Capability {
    NATIVE_ASSET,
    NATIVE_ASSET_WITH_RESOURCES,
    GEOMETRY_INSPECTION,
    SAFE_ARCHIVE,
    IMAGE_ASSET,
    CONVERTER_REQUIRED,
    SPECIALIZED_CONVERTER_REQUIRED,
    PLAN_PARSER_REQUIRED,
    TEXTURE_PIPELINE_REQUIRED,
    ENVIRONMENT_PIPELINE_REQUIRED,
    ARCHIVE_DECODER_REQUIRED
}

data class ImportedAsset(
    val displayName: String,
    val format: ImportFormat,
    /** App-private file or directory. For glTF, keep the whole resource directory together. */
    val localPath: String,
    val notes: List<String> = emptyList(),
    val vertexCount: Long? = null,
    val faceCount: Long? = null
)

sealed interface ImportResult {
    data class Success(val asset: ImportedAsset) : ImportResult
    data class UnsupportedFormat(val extension: String) : ImportResult
    data class RequiresConversion(val format: ImportFormat, val reason: String) : ImportResult
    data class Error(val message: String, val cause: Throwable? = null) : ImportResult
}
