package com.prokitchen.designer.viewer

import android.graphics.Color
import android.opengl.Matrix
import android.os.Bundle
import android.view.Choreographer
import android.view.View
import android.view.SurfaceView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.filament.Skybox
import com.google.android.filament.utils.Utils
import com.google.android.filament.utils.ModelViewer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Real-time GLB viewer using Filament's ModelViewer helper. */
class GlbViewerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_MODEL_PATH = "model_path"
        const val EXTRA_MODEL_NAME = "model_name"
    }

    private lateinit var surface: SurfaceView
    private lateinit var modelViewer: ModelViewer
    private lateinit var choreographer: Choreographer
    private lateinit var info: TextView
    private var yawDegrees = 0f
    private var flipX = false
    private var flipZ = false
    private var baseTransform: FloatArray? = null
    private var viewerCreated = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFinishing && viewerCreated) {
                choreographer.postFrameCallback(this)
                modelViewer.render(frameTimeNanos)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        choreographer = Choreographer.getInstance()
        val path = intent.getStringExtra(EXTRA_MODEL_PATH)
        if (path.isNullOrBlank() || !File(path).isFile) {
            Toast.makeText(this, "ملف GLB غير موجود", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Filament's native bindings must be initialized before creating an Engine.
        Utils.init()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 244, 239))
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6, 4, 6, 4)
        }
        fun action(label: String, click: () -> Unit) {
            toolbar.addView(Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 11f
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
        }
        action("دوران 45°") { yawDegrees = (yawDegrees + 45f) % 360f; applyObjectTransform() }
        action("عكس X") { flipX = !flipX; applyObjectTransform() }
        action("عكس Z") { flipZ = !flipZ; applyObjectTransform() }
        action("تعريض +") { adjustExposure(0.5f) }
        action("تعريض −") { adjustExposure(-0.5f) }
        action("خامة") { showMaterialPresets() }
        root.addView(toolbar)
        info = TextView(this).apply {
            text = "تحميل النموذج…"
            setTextColor(Color.DKGRAY)
            setPadding(12, 4, 12, 4)
        }
        root.addView(info)
        surface = SurfaceView(this)
        root.addView(surface, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        runCatching {
            modelViewer = ModelViewer(surface)
            viewerCreated = true
            surface.setOnTouchListener(modelViewer)
            modelViewer.scene.skybox = Skybox.Builder()
                .color(0.92f, 0.93f, 0.94f, 1f)
                .build(modelViewer.engine)
            val modelFile = File(path)
            require(modelFile.length() <= 200L * 1024L * 1024L) { "حجم النموذج أكبر من 200 MB؛ اختر نسخة أخف لتجنب نفاد الذاكرة." }
            val bytes = modelFile.readBytes()
            require(bytes.size >= 12) { "ملف GLB غير مكتمل" }
            val buffer = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            buffer.put(bytes)
            buffer.flip()
            modelViewer.loadModelGlb(buffer)
            modelViewer.transformToUnitCube()
            snapshotBaseTransform()
            info.text = "${intent.getStringExtra(EXTRA_MODEL_NAME) ?: File(path).name} • اسحب لتدوير الكاميرا، وجرّب أدوات الدوران والعكس."
        }.onFailure {
            info.text = "تعذر تحميل النموذج: ${it.message ?: "خطأ غير معروف"}"
            Toast.makeText(this, info.text, Toast.LENGTH_LONG).show()
        }
    }

    private var exposureEv = 0f

    private fun adjustExposure(delta: Float) {
        if (!viewerCreated) return
        exposureEv = (exposureEv + delta).coerceIn(-3f, 3f)
        modelViewer.camera.setExposure(16f, 1f / 125f, 100f * Math.pow(2.0, exposureEv.toDouble()).toFloat())
        info.text = "Exposure ${String.format(java.util.Locale.getDefault(), "%.1f", exposureEv)} EV"
    }

    private fun showMaterialPresets() {
        val names = arrayOf("خشب دافئ", "رخام فاتح", "جرانيت رمادي", "معدن داكن", "خرسانة")
        val colors = arrayOf(
            floatArrayOf(0.62f, 0.38f, 0.20f),
            floatArrayOf(0.88f, 0.85f, 0.78f),
            floatArrayOf(0.42f, 0.44f, 0.45f),
            floatArrayOf(0.20f, 0.22f, 0.23f),
            floatArrayOf(0.58f, 0.57f, 0.54f)
        )
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("تلوين مواد النموذج")
            .setItems(names) { _, which ->
                val changed = applyMaterialTint(colors[which][0], colors[which][1], colors[which][2])
                info.text = if (changed > 0) "تم تطبيق تلوين PBR على $changed سطح/عنصر. هذا تلوين لوني وليس استبدالًا لملفات الخامات المصورة." else "لم تتوفر معلمات لون قابلة للتعديل في خامات هذا النموذج."
            }.show()
    }

    private fun applyMaterialTint(r: Float, g: Float, b: Float): Int {
        val asset = modelViewer.asset ?: return 0
        val engine = modelViewer.engine
        val renderableManager = engine.renderableManager
        var changed = 0
        asset.renderableEntities.forEach { entity ->
            val instance = renderableManager.getInstance(entity)
            if (instance != 0) {
                for (primitive in 0 until renderableManager.getPrimitiveCount(instance)) {
                    val material = renderableManager.getMaterialInstanceAt(instance, primitive) ?: continue
                    val applied = runCatching { material.setParameter("baseColorFactor", r, g, b, 1f) }.isSuccess
                    if (applied) changed++
                }
            }
        }
        return changed
    }

    private fun snapshotBaseTransform() {
        val asset = modelViewer.asset ?: return
        val manager = modelViewer.engine.transformManager
        val instance = manager.getInstance(asset.root)
        if (instance == 0) return
        baseTransform = FloatArray(16).also { manager.getTransform(instance, it) }
    }

    /** Applies rotation and mirroring to the actual glTF root transform, not the 2D plan. */
    private fun applyObjectTransform() {
        val asset = modelViewer.asset ?: return
        val base = baseTransform ?: return
        val rootInstance = modelViewer.engine.transformManager.getInstance(asset.root)
        if (rootInstance == 0) return

        val toCenter = FloatArray(16)
        val rotation = FloatArray(16)
        val scale = FloatArray(16)
        val fromCenter = FloatArray(16)
        val temp = FloatArray(16)
        val oriented = FloatArray(16)
        Matrix.setIdentityM(toCenter, 0)
        Matrix.translateM(toCenter, 0, 0f, 0f, -4f)
        Matrix.setRotateM(rotation, 0, yawDegrees, 0f, 1f, 0f)
        Matrix.setIdentityM(scale, 0)
        Matrix.scaleM(scale, 0, if (flipX) -1f else 1f, 1f, if (flipZ) -1f else 1f)
        Matrix.setIdentityM(fromCenter, 0)
        Matrix.translateM(fromCenter, 0, 0f, 0f, 4f)
        Matrix.multiplyMM(temp, 0, rotation, 0, scale, 0)
        Matrix.multiplyMM(oriented, 0, temp, 0, fromCenter, 0)
        Matrix.multiplyMM(temp, 0, toCenter, 0, oriented, 0)
        Matrix.multiplyMM(oriented, 0, temp, 0, base, 0)
        modelViewer.engine.transformManager.setTransform(rootInstance, oriented)
    }

    override fun onResume() {
        super.onResume()
        if (viewerCreated) choreographer.postFrameCallback(frameCallback)
    }

    override fun onPause() {
        choreographer.removeFrameCallback(frameCallback)
        super.onPause()
    }

    override fun onDestroy() {
        choreographer.removeFrameCallback(frameCallback)
        // ModelViewer's UiHelper destroys its engine when the SurfaceView detaches.
        viewerCreated = false
        super.onDestroy()
    }
}
