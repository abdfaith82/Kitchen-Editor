package com.prokitchen.designer.materials

enum class MaterialCategory { WOOD, STONE, METAL, CONCRETE }
data class PbrMaterial(val id: String, val name: String, val category: MaterialCategory, val baseColorHex: String, val roughness: Float, val metallic: Float = 0f, val textureAsset: String? = null)
object PbrMaterialCatalog {
    val materials = listOf(
        PbrMaterial("oak_natural", "بلوط طبيعي", MaterialCategory.WOOD, "#B88A56", .72f),
        PbrMaterial("walnut", "جوز داكن", MaterialCategory.WOOD, "#68442E", .65f),
        PbrMaterial("marble_white", "رخام أبيض", MaterialCategory.STONE, "#E8E4DD", .24f),
        PbrMaterial("granite_dark", "غرانيت داكن", MaterialCategory.STONE, "#45494A", .3f),
        PbrMaterial("brushed_aluminum", "ألمنيوم مصقول", MaterialCategory.METAL, "#A9B0B2", .28f, .82f),
        PbrMaterial("concrete_light", "خرسانة فاتحة", MaterialCategory.CONCRETE, "#B9B8B1", .88f)
    )
    fun filter(category: MaterialCategory?) = materials.filter { category == null || it.category == category }
}
