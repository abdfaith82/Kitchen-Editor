package com.prokitchen.designer.importer

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * First-stage importer for Android Storage Access Framework URIs.
 * GLB is copied and header-validated; OBJ is inspected, not converted to GLB.
 * Other formats return RequiresConversion rather than pretending to decode them.
 */
class UniversalObjectImporter(private val context: Context) {
    companion object {
        const val MAX_SINGLE_FILE_BYTES = 512L * 1024L * 1024L
        const val MAX_ARCHIVE_ENTRIES = 2_000
        const val MAX_ARCHIVE_UNPACKED_BYTES = 1_024L * 1024L * 1024L
        private const val GLB_MAGIC = 0x46546C67
    }

    suspend fun importFile(uri: Uri, onProgress: (Float, String) -> Unit = { _, _ -> }): ImportResult =
        withContext(Dispatchers.IO) {
            try {
                onProgress(0f, "قراءة بيانات الملف")
                val displayName = queryDisplayName(context.contentResolver, uri) ?: "imported_asset"
                val extension = displayName.substringAfterLast('.', "").lowercase()
                val format = ImportFormat.fromExtension(extension)
                    ?: return@withContext ImportResult.UnsupportedFormat(extension)

                when (format) {
                    ImportFormat.GLB -> {
                        onProgress(0.15f, "نسخ ملف GLB والتحقق منه")
                        val target = copyToPrivateFile(uri, safeFileName(displayName, "glb"))
                        validateGlb(target)?.let { return@withContext ImportResult.Error(it) }
                        onProgress(1f, "تم استيراد GLB")
                        ImportResult.Success(ImportedAsset(displayName, format, target.absolutePath))
                    }
                    ImportFormat.OBJ -> {
                        onProgress(0.2f, "فحص هندسة OBJ")
                        val target = copyToPrivateFile(uri, safeFileName(displayName, "obj"))
                        val stats = inspectObj(target)
                        if (stats.first == 0L) return@withContext ImportResult.Error("لم يتم العثور على رؤوس هندسية صالحة في ملف OBJ")
                        onProgress(1f, "اكتمل الفحص؛ لم يحدث تحويل إلى GLB")
                        ImportResult.Success(
                            ImportedAsset(displayName, format, target.absolutePath,
                                notes = listOf("تم فحص OBJ فقط؛ التحويل إلى GLB يحتاج محوّلاً فعليًا.", "ملفات MTL والخامات المرتبطة يجب استيرادها مع النموذج."),
                                vertexCount = stats.first, faceCount = stats.second)
                        )
                    }
                    ImportFormat.ZIP -> {
                        onProgress(0.1f, "فك أرشيف ZIP بأمان")
                        val folder = extractZipSafely(uri)
                        val model = folder.walkTopDown().firstOrNull { it.isFile && ImportFormat.fromExtension(it.extension) in setOf(ImportFormat.GLB, ImportFormat.GLTF, ImportFormat.OBJ) }
                            ?: return@withContext ImportResult.Error("الأرشيف لا يحتوي على GLB أو glTF أو OBJ معروف")
                        val modelFormat = ImportFormat.fromExtension(model.extension)!!
                        if (modelFormat == ImportFormat.GLB) validateGlb(model)?.let { return@withContext ImportResult.Error(it) }
                        onProgress(1f, "تم استخراج الأرشيف")
                        ImportResult.Success(ImportedAsset(model.name, modelFormat, model.absolutePath,
                            notes = listOf("تم الاحتفاظ بمحتويات الأرشيف داخل مجلد خاص؛ ملفات glTF والخامات تحتاج إلى إبقاء المسارات النسبية.")))
                    }
                    ImportFormat.PNG, ImportFormat.JPG -> {
                        val target = copyToPrivateFile(uri, safeFileName(displayName, extension))
                        ImportResult.Success(ImportedAsset(displayName, format, target.absolutePath,
                            notes = listOf("تم استيراد الصورة كأصل؛ لم تُحوّل إلى مخطط تلقائيًا.")))
                    }
                    else -> ImportResult.RequiresConversion(format, conversionMessage(format))
                }
            } catch (e: SecurityException) {
                ImportResult.Error("لا توجد صلاحية لقراءة الملف. أعد اختياره من منتقي الملفات.", e)
            } catch (e: Exception) {
                ImportResult.Error(e.message ?: "فشل استيراد الملف", e)
            }
        }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? =
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }

    private fun copyToPrivateFile(uri: Uri, fileName: String): File {
        val dir = File(context.filesDir, "imported_assets").apply { mkdirs() }
        val target = File(dir, "${UUID.randomUUID()}_$fileName")
        val input = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح الملف")
        input.use { source ->
            FileOutputStream(target).use { output ->
                val buffer = ByteArray(64 * 1024)
                var total = 0L
                while (true) {
                    val count = source.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_SINGLE_FILE_BYTES) { "حجم الملف يتجاوز الحد المسموح (512 MB)" }
                    output.write(buffer, 0, count)
                }
            }
        }
        return target
    }

    private fun validateGlb(file: File): String? {
        if (file.length() < 12) return "ملف GLB أقصر من ترويسة glTF المطلوبة"
        file.inputStream().buffered().use { input ->
            val header = ByteArray(12)
            if (input.read(header) != 12) return "تعذر قراءة ترويسة GLB"
            fun u32(offset: Int): Long = (header[offset].toLong() and 0xff) or
                ((header[offset + 1].toLong() and 0xff) shl 8) or
                ((header[offset + 2].toLong() and 0xff) shl 16) or
                ((header[offset + 3].toLong() and 0xff) shl 24)
            if (u32(0).toInt() != GLB_MAGIC) return "توقيع الملف غير صالح؛ ليس GLB صحيحًا"
            if (u32(4) != 2L) return "الإصدار المدعوم هنا هو GLB 2.0 فقط"
            if (u32(8) != file.length()) return "حجم GLB داخل الترويسة لا يطابق حجم الملف"
        }
        return null
    }

    private fun inspectObj(file: File): Pair<Long, Long> {
        var vertices = 0L
        var faces = 0L
        file.bufferedReader().useLines { lines ->
            lines.forEach { raw ->
                val line = raw.trimStart()
                when {
                    line.startsWith("v ") || line.startsWith("v\t") -> vertices++
                    line.startsWith("f ") || line.startsWith("f\t") -> faces++
                }
            }
        }
        return vertices to faces
    }

    private fun extractZipSafely(uri: Uri): File {
        val root = File(context.cacheDir, "object_import_${UUID.randomUUID()}").apply { mkdirs() }
        var entries = 0
        var totalBytes = 0L
        val input = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح الأرشيف")
        try {
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entries++
                    require(entries <= MAX_ARCHIVE_ENTRIES) { "الأرشيف يحتوي على عدد كبير من الملفات" }
                    val outputFile = File(root, entry.name).canonicalFile
                    require(outputFile.toPath().startsWith(root.canonicalFile.toPath())) { "مسار غير آمن داخل الأرشيف" }
                    if (entry.isDirectory) outputFile.mkdirs() else {
                        outputFile.parentFile?.mkdirs()
                        FileOutputStream(outputFile).use { output ->
                            val buffer = ByteArray(32 * 1024)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                totalBytes += count
                                require(totalBytes <= MAX_ARCHIVE_UNPACKED_BYTES) { "حجم فك الضغط يتجاوز 1 GB" }
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
        } catch (e: Exception) {
            root.deleteRecursively()
            throw e
        }
        return root
    }

    private fun safeFileName(name: String, extension: String): String {
        val base = name.substringBeforeLast('.', name).replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
        return "${base.ifBlank { "asset" }}.$extension"
    }

    private fun conversionMessage(format: ImportFormat): String = when (format) {
        ImportFormat.FBX, ImportFormat.THREE_DS, ImportFormat.DAE, ImportFormat.PLY, ImportFormat.STL,
        ImportFormat.DXF, ImportFormat.USD, ImportFormat.USDZ, ImportFormat.ABC, ImportFormat.BLEND ->
            "الصيغة معروفة لكن محوّلها غير مدمج بعد. يلزم بناء Assimp/محوّل أصلي مناسب واختبار التوافق."
        ImportFormat.SKP, ImportFormat.RHINO, ImportFormat.IFC, ImportFormat.REVIT, ImportFormat.DWG, ImportFormat.DWF ->
            "تحتاج هذه الصيغة إلى قارئ/SDK متخصص أو خدمة تحويل مرخصة؛ لا يمكن افتراض دعمها بواسطة Assimp وحده."
        ImportFormat.PDF, ImportFormat.SVG -> "استيراد المخطط يحتاج محللًا يحول العناصر إلى نموذج هندسي، وليس مجرد فتح الملف."
        ImportFormat.KTX, ImportFormat.KTX2 -> "يلزم دمج مسار تحميل الخامات والتحقق من دعم GPU قبل ربطها بالمشهد."
        ImportFormat.HDR, ImportFormat.EXR -> "يلزم مسار لتحويل صورة البيئة إلى صيغة متوافقة مع محرك الرندر."
        ImportFormat.SEVEN_Z, ImportFormat.RAR -> "يلزم دمج مكتبة فك ضغط لهذه الصيغة؛ ZIP فقط متاح في هذا الإصدار الأولي."
        else -> "هذه الصيغة غير مدعومة في مسار الاستيراد الفعلي الحالي."
    }
}
