package com.prokitchen.designer.camera

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Offline, heuristic edge analysis for a room photo.
 * It is intentionally not advertised as AI measurement: a single perspective photo cannot
 * recover metric room dimensions without calibration, depth, or known reference measurements.
 */
object RoomImageAnalyzer {
    data class Result(
        val width: Int,
        val height: Int,
        val edgeDensity: Float,
        val horizontalEdgeScore: Float,
        val verticalEdgeScore: Float,
        val suggestedAspectRatio: Float,
        val confidence: String
    )

    fun analyze(source: Bitmap): Result {
        val maxSide = 256
        val scale = min(1f, maxSide.toFloat() / max(source.width, source.height).toFloat())
        val w = max(16, (source.width * scale).toInt())
        val h = max(16, (source.height * scale).toInt())
        val small = Bitmap.createScaledBitmap(source, w, h, true)
        val gray = IntArray(w * h)
        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val c = pixels[i]
            gray[i] = ((c shr 16 and 0xff) * 299 + (c shr 8 and 0xff) * 587 + (c and 0xff) * 114) / 1000
        }
        var horizontal = 0L
        var vertical = 0L
        var edges = 0L
        var samples = 0L
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -gray[i-w-1] + gray[i-w+1] - 2*gray[i-1] + 2*gray[i+1] - gray[i+w-1] + gray[i+w+1]
            val gy = -gray[i-w-1] - 2*gray[i-w] - gray[i-w+1] + gray[i+w-1] + 2*gray[i+w] + gray[i+w+1]
            val ax = abs(gx)
            val ay = abs(gy)
            horizontal += ay.toLong()
            vertical += ax.toLong()
            if (ax + ay > 90) edges++
            samples++
        }
        if (small !== source) small.recycle()
        val density = if (samples == 0L) 0f else edges.toFloat() / samples.toFloat()
        val hs = if (horizontal + vertical == 0L) 0.5f else horizontal.toFloat() / (horizontal + vertical).toFloat()
        val vs = 1f - hs
        // Weak visual hint only. Perspective distortion means this is not a room measurement.
        val ratio = (source.width.toFloat() / source.height.toFloat()).coerceIn(0.65f, 1.8f)
        val confidence = when {
            density < 0.025f -> "منخفضة جدًا: تفاصيل الحواف قليلة"
            density > 0.28f -> "منخفضة: الصورة مزدحمة بالتفاصيل"
            else -> "استكشافية فقط؛ يلزم إدخال قياس حقيقي"
        }
        return Result(w, h, density, hs, vs, ratio, confidence)
    }
}
