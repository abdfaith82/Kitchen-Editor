package com.prokitchen.designer.importer

/** Register ActivityResultContracts.OpenDocument() and launch(MIME_TYPES). */
object ImportPickerContract {
    /** Keep this broad: extension and content are validated by UniversalObjectImporter afterwards. */
    val MIME_TYPES: Array<String> = arrayOf("*/*")
}
