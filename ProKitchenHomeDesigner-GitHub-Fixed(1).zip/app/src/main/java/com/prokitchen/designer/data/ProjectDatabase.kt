package com.prokitchen.designer.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String = "current",
    val name: String,
    val json: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1") suspend fun get(id: String = "current"): ProjectEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(project: ProjectEntity)
}

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
abstract class ProjectDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    companion object {
        @Volatile private var instance: ProjectDatabase? = null
        fun get(context: Context): ProjectDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, ProjectDatabase::class.java, "prokitchen.db").build().also { instance = it }
        }
    }
}
