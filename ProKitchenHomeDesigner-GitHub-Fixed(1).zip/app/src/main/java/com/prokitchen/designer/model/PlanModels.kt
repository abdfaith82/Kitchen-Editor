package com.prokitchen.designer.model

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.hypot

enum class ElementType { WALL, WINDOW, DOOR, FURNITURE, LABEL }

data class PlanElement(
    val id: Long,
    val type: ElementType,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val label: String = "",
    val widthCm: Float = 12f,
    val rotationDegrees: Int = 0,
    val flipX: Boolean = false,
    val flipY: Boolean = false,
    val quantity: Int = 1,
    val material: String = "غير محدد",
    val unitCost: Double = 0.0
)

data class PlanDocument(
    val name: String = "My Kitchen",
    val widthCm: Float = 420f,
    val depthCm: Float = 360f,
    val wallHeightCm: Float = 280f,
    val elements: MutableList<PlanElement> = mutableListOf()
) {
    fun addDefaultRoom() {
        if (elements.isNotEmpty()) return
        val w = widthCm; val h = depthCm
        elements += PlanElement(1, ElementType.WALL, 0f, 0f, w, 0f, widthCm = 15f)
        elements += PlanElement(2, ElementType.WALL, w, 0f, w, h, widthCm = 15f)
        elements += PlanElement(3, ElementType.WALL, w, h, 0f, h, widthCm = 15f)
        elements += PlanElement(4, ElementType.WALL, 0f, h, 0f, 0f, widthCm = 15f)
        elements += PlanElement(5, ElementType.WINDOW, 140f, 0f, 250f, 0f, "Window")
        elements += PlanElement(6, ElementType.DOOR, 0f, 240f, 0f, 330f, "Door")
        elements += PlanElement(7, ElementType.FURNITURE, 45f, 35f, 180f, 85f, "Counter")
        elements += PlanElement(8, ElementType.FURNITURE, 255f, 35f, 375f, 85f, "Hob")
        elements += PlanElement(9, ElementType.FURNITURE, 145f, 220f, 275f, 300f, "Island")
    }

    fun toJson(): String {
        val root = JSONObject().put("name", name).put("widthCm", widthCm)
            .put("depthCm", depthCm).put("wallHeightCm", wallHeightCm)
        val arr = JSONArray()
        elements.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("type", e.type.name)
                .put("x1", e.x1).put("y1", e.y1).put("x2", e.x2).put("y2", e.y2)
                .put("label", e.label).put("widthCm", e.widthCm).put("rotationDegrees", e.rotationDegrees).put("flipX", e.flipX).put("flipY", e.flipY)
                .put("quantity", e.quantity).put("material", e.material).put("unitCost", e.unitCost))
        }
        return root.put("elements", arr).toString(2)
    }

    companion object {
        fun fromJson(json: String): PlanDocument {
            val root = JSONObject(json)
            val doc = PlanDocument(
                name = root.optString("name", "Imported Plan"),
                widthCm = root.optDouble("widthCm", 420.0).toFloat(),
                depthCm = root.optDouble("depthCm", 360.0).toFloat(),
                wallHeightCm = root.optDouble("wallHeightCm", 280.0).toFloat()
            )
            val arr = root.optJSONArray("elements") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                doc.elements += PlanElement(
                    o.optLong("id"), runCatching { ElementType.valueOf(o.optString("type")) }.getOrDefault(ElementType.WALL),
                    o.optDouble("x1").toFloat(), o.optDouble("y1").toFloat(),
                    o.optDouble("x2").toFloat(), o.optDouble("y2").toFloat(),
                    o.optString("label"), o.optDouble("widthCm", 12.0).toFloat(), o.optInt("rotationDegrees", 0), o.optBoolean("flipX", false), o.optBoolean("flipY", false),
                    o.optInt("quantity", 1).coerceAtLeast(1), o.optString("material", "غير محدد"), o.optDouble("unitCost", 0.0).coerceAtLeast(0.0)
                )
            }
            return doc
        }
    }
}

fun distanceCm(e: PlanElement) = hypot((e.x2 - e.x1).toDouble(), (e.y2 - e.y1).toDouble()).toFloat()
fun snapAngle(x1: Float, y1: Float, x2: Float, y2: Float): Pair<Float, Float> {
    val dx = x2 - x1; val dy = y2 - y1
    val length = hypot(dx, dy)
    if (length < 1f) return x2 to y2
    val angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble()))
    val snapped = when {
        abs(angle) < 10 || abs(angle) > 170 -> if (dx >= 0) 0.0 else 180.0
        abs(abs(angle) - 90) < 10 -> if (dy >= 0) 90.0 else -90.0
        abs(abs(angle) - 45) < 5 -> angle
        else -> angle
    }
    val rad = Math.toRadians(snapped)
    return (x1 + length * kotlin.math.cos(rad)).toFloat() to (y1 + length * kotlin.math.sin(rad)).toFloat()
}
