package com.prokitchen.designer.render

import com.google.android.filament.View

/**
 * Applies only options exposed by the public Filament Android API.
 * Call on the thread that owns the Filament View, typically the GL/render thread.
 */
object FilamentPostProcessing {

    fun apply(view: View, profile: RenderProfile): RenderProfileResult {
        val ao = view.ambientOcclusionOptions
        val bloom = view.bloomOptions
        val taa = view.temporalAntiAliasingOptions
        val ssr = view.screenSpaceReflectionsOptions

        var appliedProfile = profile
        var customNotice: String? = null
        when (profile) {
            RenderProfile.PREVIEW -> {
                ao.enabled = false
                bloom.enabled = false
                taa.enabled = false
                ssr.enabled = false
                view.antiAliasing = View.AntiAliasing.FXAA
            }

            RenderProfile.QUALITY -> {
                ao.enabled = true
                ao.quality = View.QualityLevel.MEDIUM
                ao.radius = 0.3f
                ao.intensity = 1.0f
                bloom.enabled = true
                bloom.strength = 0.08f
                bloom.quality = View.QualityLevel.MEDIUM
                taa.enabled = false
                ssr.enabled = true
                view.antiAliasing = View.AntiAliasing.FXAA
            }

            RenderProfile.ULTRA_PATH_TRACING -> {
                // Use the highest practical real-time settings, but do not label
                // this as path tracing: this profile does not implement it.
                ao.enabled = true
                ao.quality = View.QualityLevel.ULTRA
                ao.radius = 0.5f
                ao.intensity = 1.2f
                bloom.enabled = true
                bloom.strength = 0.12f
                bloom.quality = View.QualityLevel.HIGH
                taa.enabled = true
                taa.feedback = 0.12f
                taa.filterWidth = 1.0f
                ssr.enabled = true
                view.antiAliasing = View.AntiAliasing.FXAA
                appliedProfile = RenderProfile.QUALITY
                customNotice = "تم تطبيق إعدادات real-time عالية الجودة. Path tracing غير منفذ في هذا المحرك."
            }

            RenderProfile.EXPORT_4K -> {
                ao.enabled = true
                ao.quality = View.QualityLevel.HIGH
                ao.radius = 0.4f
                ao.intensity = 1.1f
                bloom.enabled = true
                bloom.strength = 0.1f
                bloom.quality = View.QualityLevel.HIGH
                taa.enabled = true
                taa.feedback = 0.1f
                taa.filterWidth = 1.0f
                ssr.enabled = true
                view.antiAliasing = View.AntiAliasing.FXAA
            }
        }

        view.ambientOcclusionOptions = ao
        view.bloomOptions = bloom
        view.temporalAntiAliasingOptions = taa
        view.screenSpaceReflectionsOptions = ssr

        return RenderProfileResult(
            requested = profile,
            applied = appliedProfile,
            notice = customNotice ?: when (profile) {
                RenderProfile.PREVIEW -> "إعدادات معاينة سريعة."
                RenderProfile.QUALITY -> "إعدادات PBR آنية مع AO وBloom وSSR حسب دعم الجهاز."
                RenderProfile.EXPORT_4K -> "تم إعداد جودة العرض؛ تصدير 4K يحتاج مسار التقاط عالي الدقة منفصلاً."
                else -> "إعدادات آنية فقط."
            }
        )
    }
}
