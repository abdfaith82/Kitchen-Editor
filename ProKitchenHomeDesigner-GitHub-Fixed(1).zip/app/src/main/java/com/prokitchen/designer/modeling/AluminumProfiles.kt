package com.prokitchen.designer.modeling

import java.io.File

/** First-fit decreasing cut planner. Kerf is added to every cut for conservative stock planning. */
object AluminumProfiles {
    data class Cut(val label: String, val lengthMm: Int, val quantity: Int = 1) { init { require(lengthMm > 0 && quantity > 0) } }
    data class Bar(val index: Int, val cutsMm: List<Int>, val usedMm: Int, val wasteMm: Int)
    fun optimize(cuts: List<Cut>, stockLengthMm: Int = 6000, kerfMm: Int = 3): List<Bar> {
        require(stockLengthMm > 0 && kerfMm >= 0)
        val pieces = cuts.flatMap { c -> List(c.quantity) { c.lengthMm } }.sortedDescending()
        require(pieces.all { it + kerfMm <= stockLengthMm }) { "يوجد قطع أطول من طول القضيب المتاح" }
        val bins = mutableListOf<MutableList<Int>>()
        val used = mutableListOf<Int>()
        pieces.forEach { piece ->
            val size = piece + kerfMm
            val i = used.indexOfFirst { it + size <= stockLengthMm }
            if (i >= 0) { bins[i].add(piece); used[i] += size } else { bins.add(mutableListOf(piece)); used.add(size) }
        }
        return bins.mapIndexed { i, list -> Bar(i+1, list.toList(), used[i], stockLengthMm-used[i]) }
    }
    fun exportCsv(bars: List<Bar>, file: File) {
        file.bufferedWriter().use { out ->
            out.appendLine("bar_index,cuts_mm,used_mm,waste_mm")
            bars.forEach { out.appendLine("${it.index},\"${it.cutsMm.joinToString(";")}\",${it.usedMm},${it.wasteMm}") }
        }
    }
}
