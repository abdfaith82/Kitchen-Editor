package com.prokitchen.designer.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import com.prokitchen.designer.model.*
import java.io.File
import java.io.FileOutputStream
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

object BillOfMaterials {
    data class Row(val name: String, val quantity: Int, val widthCm: Int, val depthCm: Int, val material: String = "غير محدد", val unitCost: Double = 0.0) {
        val total get() = quantity * unitCost
    }
    fun from(doc: PlanDocument): List<Row> = doc.elements.filter { it.type == ElementType.FURNITURE }.map {
        Row(
            name = it.label.ifBlank { "وحدة مطبخ" },
            quantity = it.quantity.coerceAtLeast(1),
            widthCm = kotlin.math.abs(it.x2 - it.x1).toInt(),
            depthCm = kotlin.math.abs(it.y2 - it.y1).toInt(),
            material = it.material,
            unitCost = it.unitCost.coerceAtLeast(0.0)
        )
    }
}

object ObjLayoutExporter {
    /** Exports a coarse cabinet/room blockout, not the original editable 3D meshes. Units are meters. */
    fun write(doc: PlanDocument, file: File) {
        file.bufferedWriter().use { out ->
            out.appendLine("# ProKitchen layout blockout; units: meters")
            var vertex = 1
            doc.elements.filter { it.type == ElementType.FURNITURE }.forEach { e ->
                val x1=min(e.x1,e.x2)/100f; val x2=max(e.x1,e.x2)/100f
                val z1=min(e.y1,e.y2)/100f; val z2=max(e.y1,e.y2)/100f
                val y0=0f; val y1=0.9f
                out.appendLine("o ${e.label.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "Cabinet" }}")
                listOf("$x1 $y0 $z1", "$x2 $y0 $z1", "$x2 $y0 $z2", "$x1 $y0 $z2", "$x1 $y1 $z1", "$x2 $y1 $z1", "$x2 $y1 $z2", "$x1 $y1 $z2").forEach { out.appendLine("v $it") }
                listOf("1 2 3 4", "5 8 7 6", "1 5 6 2", "2 6 7 3", "3 7 8 4", "5 1 4 8").forEach { face -> out.appendLine("f " + face.split(" ").joinToString(" ") { (it.toInt()+vertex-1).toString() }) }
                vertex += 8
            }
        }
    }
}



object GltfLayoutExporter {
    /** Writes a valid glTF 2.0 JSON file with embedded binary data for simple cabinet blockout meshes. */
    fun write(doc: PlanDocument, file: File) {
        val units = doc.elements.filter { it.type == ElementType.FURNITURE }
        require(units.isNotEmpty()) { "أضف وحدة أثاث واحدة على الأقل قبل تصدير GLTF" }
        val binary = java.io.ByteArrayOutputStream()
        val views = org.json.JSONArray()
        val accessors = org.json.JSONArray()
        val meshes = org.json.JSONArray()
        val nodes = org.json.JSONArray()
        units.forEachIndexed { index, element ->
            val x = min(element.x1, element.x2) / 100f
            val z = min(element.y1, element.y2) / 100f
            val w = max(0.01f, kotlin.math.abs(element.x2 - element.x1) / 100f)
            val d = max(0.01f, kotlin.math.abs(element.y2 - element.y1) / 100f)
            val h = 0.9f
            val faces = listOf(
                floatArrayOf(0f,0f,1f,  1f,0f,1f,  1f,1f,1f,  0f,1f,1f),
                floatArrayOf(1f,0f,0f,  0f,0f,0f,  0f,1f,0f,  1f,1f,0f),
                floatArrayOf(0f,0f,0f,  0f,0f,1f,  0f,1f,1f,  0f,1f,0f),
                floatArrayOf(1f,0f,1f,  1f,0f,0f,  1f,1f,0f,  1f,1f,1f),
                floatArrayOf(0f,1f,1f,  1f,1f,1f,  1f,1f,0f,  0f,1f,0f),
                floatArrayOf(0f,0f,0f,  1f,0f,0f,  1f,0f,1f,  0f,0f,1f)
            )
            val normals = listOf(
                floatArrayOf(0f,0f,1f), floatArrayOf(0f,0f,-1f), floatArrayOf(-1f,0f,0f),
                floatArrayOf(1f,0f,0f), floatArrayOf(0f,1f,0f), floatArrayOf(0f,-1f,0f)
            )
            val positionBytes = java.nio.ByteBuffer.allocate(24 * 3 * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            val normalBytes = java.nio.ByteBuffer.allocate(24 * 3 * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            faces.forEachIndexed { faceIndex, coords ->
                for (v in 0 until 4) {
                    positionBytes.putFloat(coords[v * 3] * w - w / 2f)
                    positionBytes.putFloat(coords[v * 3 + 1] * h)
                    positionBytes.putFloat(coords[v * 3 + 2] * d - d / 2f)
                    normalBytes.putFloat(normals[faceIndex][0])
                    normalBytes.putFloat(normals[faceIndex][1])
                    normalBytes.putFloat(normals[faceIndex][2])
                }
            }
            val indices = java.nio.ByteBuffer.allocate(36 * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            for (face in 0 until 6) {
                val base = face * 4
                listOf(base, base+1, base+2, base, base+2, base+3).forEach { indices.putShort(it.toShort()) }
            }
            while (binary.size() % 4 != 0) binary.write(0)
            val posOffset = binary.size(); binary.write(positionBytes.array())
            while (binary.size() % 4 != 0) binary.write(0)
            val normOffset = binary.size(); binary.write(normalBytes.array())
            while (binary.size() % 4 != 0) binary.write(0)
            val idxOffset = binary.size(); binary.write(indices.array())

            val posView = views.length(); views.put(JSONObject().put("buffer",0).put("byteOffset",posOffset).put("byteLength",positionBytes.capacity()).put("target",34962))
            val normView = views.length(); views.put(JSONObject().put("buffer",0).put("byteOffset",normOffset).put("byteLength",normalBytes.capacity()).put("target",34962))
            val idxView = views.length(); views.put(JSONObject().put("buffer",0).put("byteOffset",idxOffset).put("byteLength",indices.capacity()).put("target",34963))
            val posAccessor = accessors.length(); accessors.put(JSONObject().put("bufferView",posView).put("componentType",5126).put("count",24).put("type","VEC3").put("min", org.json.JSONArray(listOf(-w/2f,0f,-d/2f))).put("max", org.json.JSONArray(listOf(w/2f,h,d/2f))))
            val normAccessor = accessors.length(); accessors.put(JSONObject().put("bufferView",normView).put("componentType",5126).put("count",24).put("type","VEC3"))
            val idxAccessor = accessors.length(); accessors.put(JSONObject().put("bufferView",idxView).put("componentType",5123).put("count",36).put("type","SCALAR").put("min",org.json.JSONArray(listOf(0))).put("max",org.json.JSONArray(listOf(23))))
            meshes.put(JSONObject().put("name", element.label.ifBlank { "Cabinet_${index+1}" }).put("primitives", org.json.JSONArray().put(JSONObject().put("attributes",JSONObject().put("POSITION",posAccessor).put("NORMAL",normAccessor)).put("indices",idxAccessor).put("material",0))))
            val node = JSONObject().put("mesh", index).put("name", element.label.ifBlank { "Cabinet_${index+1}" }).put("translation", org.json.JSONArray(listOf(x + w/2f, 0f, z + d/2f)))
            if (element.flipX || element.flipY) node.put("scale", org.json.JSONArray(listOf(if (element.flipX) -1f else 1f, 1f, if (element.flipY) -1f else 1f)))
            if (element.rotationDegrees != 0) {
                val radians = Math.toRadians(element.rotationDegrees.toDouble())
                node.put("rotation", org.json.JSONArray(listOf(0, kotlin.math.sin(radians/2), 0, kotlin.math.cos(radians/2))))
            }
            nodes.put(node)
        }
        val bytes = binary.toByteArray()
        val gltf = JSONObject()
            .put("asset", JSONObject().put("version", "2.0").put("generator", "ProKitchen Designer"))
            .put("scene", 0)
            .put("scenes", org.json.JSONArray().put(JSONObject().put("nodes", org.json.JSONArray((0 until nodes.length()).toList()))))
            .put("nodes", nodes)
            .put("meshes", meshes)
            .put("materials", org.json.JSONArray().put(JSONObject().put("name","Cabinet neutral PBR").put("pbrMetallicRoughness", JSONObject().put("baseColorFactor",org.json.JSONArray(listOf(0.72,0.66,0.54,1.0))).put("metallicFactor",0.05).put("roughnessFactor",0.72))))
            .put("buffers", org.json.JSONArray().put(JSONObject().put("byteLength",bytes.size).put("uri","data:application/octet-stream;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))))
            .put("bufferViews", views)
            .put("accessors", accessors)
        file.parentFile?.mkdirs()
        file.writeText(gltf.toString(2))
    }
}


object DesignPdfExporter {
    fun write(context: Context, doc: PlanDocument, planBitmap: Bitmap?, file: File) {
        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas; val p = Paint(3)
        p.color = Color.rgb(22,56,59); p.textSize = 22f; p.isFakeBoldText = true
        c.drawText("ProKitchen — Design Summary", 36f, 44f, p)
        p.color = Color.DKGRAY; p.textSize = 12f; p.isFakeBoldText = false
        c.drawText("${doc.name}   |   ${doc.widthCm.toInt()} × ${doc.depthCm.toInt()} cm", 36f, 66f, p)
        if (planBitmap != null) {
            val maxW=520f; val maxH=330f; val ratio=min(maxW/planBitmap.width, maxH/planBitmap.height)
            c.drawBitmap(planBitmap, null, RectF(36f, 88f, 36f+planBitmap.width*ratio, 88f+planBitmap.height*ratio), p)
        }
        var y=450f
        p.textSize=15f; p.isFakeBoldText=true; c.drawText("Bill of Materials",36f,y,p); y+=24f
        p.textSize=9f; p.isFakeBoldText=false
        c.drawText("Item",36f,y,p); c.drawText("Material",170f,y,p); c.drawText("Size",260f,y,p); c.drawText("Qty",340f,y,p); c.drawText("Unit",390f,y,p); c.drawText("Total",480f,y,p); y+=17f
        val rows = BillOfMaterials.from(doc)
        rows.take(18).forEach { row ->
            c.drawText(row.name.take(20),36f,y,p); c.drawText(row.material.take(13),170f,y,p); c.drawText("${row.widthCm}×${row.depthCm}",260f,y,p)
            c.drawText(row.quantity.toString(),340f,y,p); c.drawText(String.format(java.util.Locale.US, "%.2f", row.unitCost),390f,y,p)
            c.drawText(String.format(java.util.Locale.US, "%.2f", row.total),480f,y,p); y+=17f
        }
        if (rows.isEmpty()) c.drawText("No cabinet units added.",36f,y,p)
        y += 22f
        p.isFakeBoldText = true
        c.drawText("Estimated total: ${String.format(java.util.Locale.US, "%.2f", rows.sumOf { it.total })}",36f,y,p)
        p.isFakeBoldText = false
        pdf.finishPage(page); file.parentFile?.mkdirs(); FileOutputStream(file).use { pdf.writeTo(it) }; pdf.close()
    }
}
