package com.prokitchen.designer.camera

import android.content.Context
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File

class CameraScanView(context: Context, private val owner: LifecycleOwner) : FrameLayout(context) {
    private val previewView = PreviewView(context)
    private var imageCapture: ImageCapture? = null
    var onImageSaved: ((File) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    init {
        addView(previewView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            }.onFailure { onError?.invoke(it.message ?: "تعذر تشغيل الكاميرا") }
        }, ContextCompat.getMainExecutor(context))
    }
    fun captureTo(file: File) {
        val capture = imageCapture ?: run { onError?.invoke("الكاميرا غير جاهزة بعد"); return }
        capture.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(), ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) { onImageSaved?.invoke(file) }
            override fun onError(exception: ImageCaptureException) { onError?.invoke(exception.message ?: "فشل التقاط الصورة") }
        })
    }
}
