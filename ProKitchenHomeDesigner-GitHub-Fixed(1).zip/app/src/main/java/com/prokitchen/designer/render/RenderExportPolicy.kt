package com.prokitchen.designer.render

/**
 * Validates render export requests before allocating large buffers.
 * This is a policy/helper only; it does not capture a Filament scene.
 */
data class ExportSpec(val width: Int, val height: Int, val samples: Int = 1) {
    val pixelCount: Long get() = width.toLong() * height.toLong()
}

object RenderExportPolicy {
    const val MAX_SAFE_BITMAP_PIXELS: Long = 16_000_000L

    fun specFor(profile: RenderProfile): ExportSpec = when (profile) {
        RenderProfile.PREVIEW -> ExportSpec(1280, 720)
        RenderProfile.QUALITY -> ExportSpec(1920, 1080)
        RenderProfile.EXPORT_4K -> ExportSpec(3840, 2160)
        RenderProfile.ULTRA_PATH_TRACING -> ExportSpec(1920, 1080, samples = 64)
    }

    fun validate(spec: ExportSpec): String? {
        if (spec.width <= 0 || spec.height <= 0) return "أبعاد الصورة يجب أن تكون أكبر من صفر."
        if (spec.samples !in 1..4096) return "عدد العينات خارج النطاق المدعوم."
        if (spec.pixelCount > MAX_SAFE_BITMAP_PIXELS) {
            return "الدقة المطلوبة تتجاوز حد الذاكرة الآمن الافتراضي؛ استخدم التصدير المجزأ أو خدمة رندر."
        }
        return null
    }
}
