package com.prokitchen.designer.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import com.prokitchen.designer.model.*
import kotlin.math.max
import kotlin.math.min

class PlanCanvasView(context: Context, private val doc: PlanDocument) : View(context) {
    enum class Tool { WALL, WINDOW, DOOR, FURNITURE, SELECT, ERASE }
    var showDistances: Boolean = true
    var selectedId: Long? = null
    private var movingElement: PlanElement? = null
    private var moveOriginX = 0f
    private var moveOriginY = 0f
    private var originalElement: PlanElement? = null
    private var ghostX = 0f
    private var ghostY = 0f
    var tool: Tool = Tool.WALL
        set(value) { field = value; invalidate() }
    var onChanged: (() -> Unit)? = null
    private val gridPaint = Paint(3).apply { color = Color.rgb(231, 235, 232); strokeWidth = 1f }
    private val wallPaint = Paint(3).apply { color = Color.rgb(35, 54, 54); strokeWidth = 10f; strokeCap = Paint.Cap.ROUND }
    private val windowPaint = Paint(3).apply { color = Color.rgb(36, 145, 178); strokeWidth = 7f }
    private val doorPaint = Paint(3).apply { color = Color.rgb(201, 143, 67); strokeWidth = 6f }
    private val furniturePaint = Paint(3).apply { color = Color.rgb(215, 195, 160); style = Paint.Style.FILL }
    private val outlinePaint = Paint(3).apply { color = Color.rgb(115, 92, 59); style = Paint.Style.STROKE; strokeWidth = 2f }
    private val textPaint = Paint(3).apply { color = Color.rgb(37, 58, 58); textSize = 12f; textAlign = Paint.Align.CENTER }
    private var startX = 0f; private var startY = 0f; private var currentX = 0f; private var currentY = 0f
    private var drawing = false
    private val scale get() = min((width - 56f) / doc.widthCm, (height - 56f) / doc.depthCm).coerceAtLeast(.1f)
    private val ox get() = (width - doc.widthCm * scale) / 2f
    private val oy get() = (height - doc.depthCm * scale) / 2f
    private fun sx(x: Float) = ox + x * scale
    private fun sy(y: Float) = oy + y * scale
    private fun wx(x: Float) = ((x - ox) / scale).coerceIn(0f, doc.widthCm)
    private fun wy(y: Float) = ((y - oy) / scale).coerceIn(0f, doc.depthCm)

    fun rotateSelected45() {
        val i = doc.elements.indexOfFirst { it.id == selectedId && it.type == ElementType.FURNITURE }
        if (i >= 0) { val e = doc.elements[i]; doc.elements[i] = e.copy(rotationDegrees = (e.rotationDegrees + 45) % 360); performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK); invalidate(); onChanged?.invoke() }
    }
    fun flipSelected(horizontal: Boolean) {
        val i = doc.elements.indexOfFirst { it.id == selectedId && it.type == ElementType.FURNITURE }
        if (i >= 0) { val e = doc.elements[i]; doc.elements[i] = if (horizontal) e.copy(flipX = !e.flipX) else e.copy(flipY = !e.flipY); invalidate(); onChanged?.invoke() }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(250, 249, 245))
        val step = max(10f, 25f * scale)
        var gx = ox
        while (gx <= ox + doc.widthCm * scale) { canvas.drawLine(gx, oy, gx, oy + doc.depthCm * scale, gridPaint); gx += step }
        var gy = oy
        while (gy <= oy + doc.depthCm * scale) { canvas.drawLine(ox, gy, ox + doc.widthCm * scale, gy, gridPaint); gy += step }
        doc.elements.forEach { original ->
            val e = if (movingElement?.id == original.id && originalElement != null) originalElement!! else original
            val x1 = sx(e.x1); val y1 = sy(e.y1); val x2 = sx(e.x2); val y2 = sy(e.y2)
            if (selectedId == e.id) {
                val sel = Paint(3).apply { color = Color.rgb(28, 151, 128); style = Paint.Style.STROKE; strokeWidth = 3f }
                canvas.drawRoundRect(RectF(min(x1,x2)-7, min(y1,y2)-7, max(x1,x2)+7, max(y1,y2)+7), 8f, 8f, sel)
            }
            when (e.type) {
                ElementType.WALL -> canvas.drawLine(x1, y1, x2, y2, wallPaint)
                ElementType.WINDOW -> { canvas.drawLine(x1, y1, x2, y2, windowPaint); canvas.drawLine(x1, y1 + 3, x2, y2 + 3, windowPaint) }
                ElementType.DOOR -> { canvas.drawLine(x1, y1, x2, y2, doorPaint); canvas.drawArc(min(x1,x2)-20, min(y1,y2)-20, max(x1,x2)+20, max(y1,y2)+20, 0f, 90f, false, doorPaint) }
                ElementType.FURNITURE -> {
                    val rect = RectF(min(x1,x2), min(y1,y2), max(x1,x2), max(y1,y2))
                    canvas.save()
                    canvas.rotate(e.rotationDegrees.toFloat(), rect.centerX(), rect.centerY())
                    canvas.scale(if (e.flipX) -1f else 1f, if (e.flipY) -1f else 1f, rect.centerX(), rect.centerY())
                    canvas.drawRoundRect(rect, 6f, 6f, furniturePaint); canvas.drawRoundRect(rect, 6f, 6f, outlinePaint)
                    canvas.drawText(e.label, rect.centerX(), rect.centerY(), textPaint)
                    canvas.restore()
                }
                ElementType.LABEL -> canvas.drawText(e.label, x1, y1, textPaint)
            }
        }
        if (movingElement != null && originalElement != null) {
            val e = originalElement!!
            val dx = ghostX - moveOriginX; val dy = ghostY - moveOriginY
            val ghost = Paint(3).apply { color = Color.argb(105, 37, 150, 128); style = Paint.Style.FILL }
            val rect = RectF(sx(e.x1 + dx), sy(e.y1 + dy), sx(e.x2 + dx), sy(e.y2 + dy)).apply { sort() }
            canvas.drawRoundRect(rect, 8f, 8f, ghost)
            val edge = Paint(3).apply { color = Color.rgb(24, 120, 103); style = Paint.Style.STROKE; strokeWidth = 2f }
            canvas.drawRoundRect(rect, 8f, 8f, edge)
        }
        if (showDistances && selectedId != null) {
            val selected = doc.elements.firstOrNull { it.id == selectedId && it.type == ElementType.FURNITURE }
            if (selected != null) {
                val leftGap = selected.x1.coerceAtLeast(0f)
                val rightGap = (doc.widthCm - selected.x2).coerceAtLeast(0f)
                val msg = "يسار ${leftGap.toInt()} cm  •  يمين ${rightGap.toInt()} cm"
                val bg = Paint(3).apply { color = Color.argb(220, 255, 255, 255) }
                canvas.drawRoundRect(RectF(12f, 12f, 12f + textPaint.measureText(msg) + 20f, 42f), 8f, 8f, bg)
                textPaint.textAlign = Paint.Align.LEFT
                canvas.drawText(msg, 22f, 32f, textPaint)
                textPaint.textAlign = Paint.Align.CENTER
            }
        }
        if (drawing && tool != Tool.SELECT) {
            val p = Paint(3).apply { color = Color.rgb(35, 130, 116); strokeWidth = 4f; style = Paint.Style.STROKE }
            canvas.drawLine(startX, startY, currentX, currentY, p)
            val cm = distanceCm(PlanElement(0, ElementType.WALL, wx(startX), wy(startY), wx(currentX), wy(currentY)))
            canvas.drawText("${cm.toInt()} cm", (startX+currentX)/2, (startY+currentY)/2 - 10, textPaint)
        }
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("${doc.widthCm.toInt()} × ${doc.depthCm.toInt()} cm", 16f, height - 18f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x; startY = event.y; currentX = event.x; currentY = event.y; drawing = true
                if (tool == Tool.SELECT) {
                    val px = wx(event.x); val py = wy(event.y)
                    val found = doc.elements.lastOrNull { e -> px >= min(e.x1,e.x2)-8 && px <= max(e.x1,e.x2)+8 && py >= min(e.y1,e.y2)-8 && py <= max(e.y1,e.y2)+8 }
                        ?: doc.elements.filter { it.type == ElementType.FURNITURE }.minByOrNull { kotlin.math.hypot((it.x1-px).toDouble(), (it.y1-py).toDouble()) }
                    selectedId = found?.id
                    if (found?.type == ElementType.FURNITURE) {
                        movingElement = found; originalElement = found.copy(); moveOriginX = px; moveOriginY = py; ghostX = px; ghostY = py
                        performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                    }
                    invalidate(); onChanged?.invoke(); return true
                }
                if (tool == Tool.ERASE) {
                    val wx = wx(event.x); val wy = wy(event.y)
                    val found = doc.elements.minByOrNull { kotlin.math.hypot((it.x1-wx).toDouble(), (it.y1-wy).toDouble()) }
                    if (found != null) doc.elements.remove(found)
                    drawing = false; onChanged?.invoke(); invalidate()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentX = event.x; currentY = event.y
                if (movingElement != null) { ghostX = wx(event.x); ghostY = wy(event.y); performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK) }
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                currentX = event.x; currentY = event.y; drawing = false
                if (movingElement != null && originalElement != null) {
                    val target = movingElement!!; val source = originalElement!!
                    val dx = wx(event.x) - moveOriginX; val dy = wy(event.y) - moveOriginY
                    var nx1 = (source.x1 + dx).coerceIn(0f, doc.widthCm); var ny1 = (source.y1 + dy).coerceIn(0f, doc.depthCm)
                    var nx2 = (source.x2 + dx).coerceIn(0f, doc.widthCm); var ny2 = (source.y2 + dy).coerceIn(0f, doc.depthCm)
                    // Snap furniture edges to room bounds / neighboring furniture within 12 cm.
                    val threshold = 12f
                    if (nx1 < threshold) { nx2 -= nx1; nx1 = 0f }
                    if (ny1 < threshold) { ny2 -= ny1; ny1 = 0f }
                    if (doc.widthCm - nx2 < threshold) { nx1 += doc.widthCm - nx2; nx2 = doc.widthCm }
                    if (doc.depthCm - ny2 < threshold) { ny1 += doc.depthCm - ny2; ny2 = doc.depthCm }
                    doc.elements.filter { it.type == ElementType.FURNITURE && it.id != target.id }.forEach { other ->
                        val ox1=min(other.x1,other.x2); val ox2=max(other.x1,other.x2); val oy1=min(other.y1,other.y2); val oy2=max(other.y1,other.y2)
                        if (kotlin.math.abs(nx2-ox1) < threshold && ny2 > oy1 && ny1 < oy2) { val delta=ox1-nx2; nx1+=delta; nx2+=delta }
                        if (kotlin.math.abs(nx1-ox2) < threshold && ny2 > oy1 && ny1 < oy2) { val delta=ox2-nx1; nx1+=delta; nx2+=delta }
                        if (kotlin.math.abs(ny2-oy1) < threshold && nx2 > ox1 && nx1 < ox2) { val delta=oy1-ny2; ny1+=delta; ny2+=delta }
                        if (kotlin.math.abs(ny1-oy2) < threshold && nx2 > ox1 && nx1 < ox2) { val delta=oy2-ny1; ny1+=delta; ny2+=delta }
                    }
                    val idx = doc.elements.indexOfFirst { it.id == target.id }
                    if (idx >= 0) doc.elements[idx] = target.copy(x1=nx1, y1=ny1, x2=nx2, y2=ny2)
                    movingElement = null; originalElement = null; performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM); onChanged?.invoke()
                }
                if (tool != Tool.SELECT && tool != Tool.ERASE) {
                    val x1 = wx(startX); val y1 = wy(startY)
                    val (rawX2, rawY2) = wx(currentX) to wy(currentY)
                    val (x2, y2) = snapAngle(x1, y1, rawX2, rawY2)
                    val type = when(tool) { Tool.WALL -> ElementType.WALL; Tool.WINDOW -> ElementType.WINDOW; Tool.DOOR -> ElementType.DOOR; Tool.FURNITURE -> ElementType.FURNITURE; else -> ElementType.WALL }
                    if (kotlin.math.hypot((x2-x1).toDouble(), (y2-y1).toDouble()) > 8) {
                        val id = (doc.elements.maxOfOrNull { it.id } ?: 0L) + 1
                        doc.elements += PlanElement(id, type, x1, y1, x2, y2,
                            when(type) { ElementType.FURNITURE -> "Furniture"; ElementType.WINDOW -> "Window"; ElementType.DOOR -> "Door"; else -> "" })
                        onChanged?.invoke()
                    }
                }
                invalidate(); return true
            }
        }
        return true
    }
}
