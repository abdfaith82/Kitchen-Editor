package com.prokitchen.designer.render

data class RenderConfiguration(
    val mode: Mode = Mode.LIVE,
    val exposure: Float = 0f,
    val resolution: Resolution = Resolution.FHD
) {
    enum class Mode { LIVE, FINAL }
    enum class Resolution(val width: Int, val height: Int, val label: String) {
        HD(1280, 720, "720p"), FHD(1920, 1080, "1080p"), QHD(2560, 1440, "1440p"), UHD_4K(3840, 2160, "4K UHD")
    }
}
