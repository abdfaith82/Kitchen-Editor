package com.prokitchen.designer.render

/**
 * Render presets supported by the current real-time renderer.
 * ULTRA_PATH_TRACING is deliberately marked unavailable: Filament's standard
 * Android real-time pipeline is not a path tracer.
 */
enum class RenderProfile {
    PREVIEW, QUALITY, ULTRA_PATH_TRACING, EXPORT_4K
}

data class RenderCapabilities(
    val realTimePbr: Boolean,
    val ambientOcclusion: Boolean,
    val bloom: Boolean,
    val screenSpaceReflections: Boolean,
    val temporalAntiAliasing: Boolean,
    val pathTracing: Boolean,
    val maxRecommendedExportPixels: Long
)

data class RenderProfileResult(
    val requested: RenderProfile,
    val applied: RenderProfile,
    val notice: String
)
